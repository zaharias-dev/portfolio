# Sergiu Zaharia — Portfolio

Static GitHub Pages portfolio for **Sergiu Zaharia**, Full-Stack Developer & Platform Architect.

## Deploy on GitHub Pages

1. Create a public repository named `portfolio` under the `zaharias-dev` account.
2. Upload `index.html`, `styles.css`, and `script.js` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`.
6. Save.

The site will then be available at:

`https://zaharias-dev.github.io/portfolio/`

## Current portfolio sections

- Developer profile
- Multi-Service Cloud Platform
- Catalog & Metadata Architecture
- Audio Processing Studio
- Social Analytics Hub
- Digital Rights & Claims System
- ATS Group Sensor & Monitoring Systems — archive pending
- Technical stack
- Architecture approach
- Professional scope
